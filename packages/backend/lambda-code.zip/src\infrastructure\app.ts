#!/usr/bin/env node
import 'source-map-support/register';
import * as cdk from 'aws-cdk-lib';
import { MisraPlatformStack } from './misra-platform-stack';

const app = new cdk.App();

// Deploy Full Platform Stack with all endpoints
new MisraPlatformStack(app, 'MisraPlatformStack', {
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION || 'us-east-1',
  },
});

app.synth();